import Vue from "vue"
Vue.use(require('vue-jalali-moment'));