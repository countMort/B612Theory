import Vue from "vue"
import safeFunction from "@/utils/try"
Vue.prototype.$try = safeFunction