<template>
    <div>
        <v-form class="mt-3 ml-3 hidden-sm-and-down">
            <v-text-field label="جستجو کنید" prepend-icon="mdi-cupcake" class="ml-10" append-icon="mdi-magnify"></v-text-field>
        </v-form>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>